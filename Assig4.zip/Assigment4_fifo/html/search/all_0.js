var searchData=
[
  ['data_5fitem_5ft_0',['data_item_t',['../structdata__item__t.html',1,'']]]
];
