var indexSectionsWithContent =
{
  0: "dmt",
  1: "d",
  2: "m",
  3: "mt",
  4: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Pages"
};

